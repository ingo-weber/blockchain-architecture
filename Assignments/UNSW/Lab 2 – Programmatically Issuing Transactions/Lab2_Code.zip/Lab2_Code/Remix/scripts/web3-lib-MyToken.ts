/// SPDX-License-Identifier: UNLICENSED

/// @title Libray to deploy and interact with contracts
/// @author Dilum Bandara, CSIRO's Data61

import Web3 from 'web3'
import { TransactionReceipt } from 'web3-core'
import { Contract, ContractSendMethod, Options } from 'web3-eth-contract'

/**
 * Helper class to calculate adjusted gas value that is higher than estimate
 */
class GasHelper {
    static gasMulptiplier = 1.25    // 25% more gas

    /**
     * Estimate how much gas to pay considering gas multiplier
     * @param {number} gas Gas limit
     * @return {number} Adjusted gas limit
     */
    static gasPay(gasLimit: number) {
        return Math.ceil(gasLimit * GasHelper.gasMulptiplier)
    }
}

/**
 * Get a list of accounts available from the Web3 provider (i.e., blockchain node) 
 * @return A list of addresses
 */
export const getAccounts = async (web3: Web3): Promise<string[]> =>{
    return await web3.eth.getAccounts()
}

/**
 * Deploy the given contract
 * @param {Web3} web3 Web3 provider
 * @param {string} contractName Name of the contract to deploy
 * @param {Array<any>} args List of constructor parameters
 * @param {string} from Account used to send the transaction
 * @param {number} gas Gas limit
 * @return {Options} deployed contract
 */
export const deploy = async (web3: Web3, contractName: string, args: Array<any>, from: string, gas?: number): Promise<Options> => {
    console.log(`deploying ${contractName}`)

    // Note that the script needs the ABI which is generated from the compilation artifact.
    // Make sure contract is compiled and artifacts are generated
    const artifactsPath = `browser/contracts/artifacts/${contractName}.json`

    const metadata = JSON.parse(await remix.call('fileManager', 'getFile', artifactsPath))

    const contract: Contract  = new web3.eth.Contract(metadata.abi)

    let gasPrice
    await web3.eth.getGasPrice().then((averageGasPrice) => {
        gasPrice = averageGasPrice
    }).catch(console.error)

    const contractSend: ContractSendMethod = contract.deploy({
        data: metadata.data.bytecode.object,
        arguments: args
    })
    const gasLimit = await contractSend.estimateGas({from})

    const newContractInstance = await contractSend.send({
        from,
        gas: GasHelper.gasPay(gasLimit),
        gasPrice
    })
    return newContractInstance.options    
}

/**
 * Execute a smart contract function that doesn't update ledger state
 * @param {web3} Web3 Web3 provider
 * @param {string} contractName Name of smart contract
 * @param {string} address Address of the contract already deployed
 * @param {string} functionName Function name to call
 * @param {Array<any>} args list of function parameters
 * @param {string} from Account used to send the transaction
 * @return {Options} Transaction receipt
 */
export const call = async (web3: Web3, contractName: string, address: string, functionName: string, args: Array<any>, from: string): Promise<TransactionReceipt> => {
    const artifactsPath = `browser/contracts/artifacts/${contractName}.json`
    const metadata = JSON.parse(await remix.call('fileManager', 'getFile', artifactsPath))   
    // const accounts = await web3.eth.getAccounts()
    const contract: Contract  = new web3.eth.Contract(metadata.abi, address)

    const receipt = await contract.methods[functionName](...args).call({
        from
    })
    
    return receipt
}

/**
 * Execute a smart contract function that updates ledger state
* @param {web3} Web3 Web3 provider
 * @param {string} contractName Name of smart contract
 * @param {string} address Address of the contract already deployed
 * @param {string} functionName Function name to call
 * @param {Array<any>} args list of function parameters
 * @param {string} from Account used to send the transaction
 * @return {Options} Transaction receipt
 */
export const send = async (web3: Web3, contractName: string, address: string, functionName: string, args: Array<any>, from?: string): Promise<TransactionReceipt> => {
    const artifactsPath = `browser/contracts/artifacts/${contractName}.json`
    const metadata = JSON.parse(await remix.call('fileManager', 'getFile', artifactsPath))   
    const contract: Contract  = new web3.eth.Contract(metadata.abi, address)

    let gasPrice
    await web3.eth.getGasPrice().then((averageGasPrice) => {
        gasPrice = averageGasPrice
    }).catch(console.error)

    const receipt = contract.methods[functionName](...args).send({
        from,
        gasPrice,
        gas: GasHelper.gasPay(await contract.methods[functionName](...args).estimateGas({ from }))
    })

    return receipt  
}

