/// SPDX-License-Identifier: UNLICENSED

/// @title Deploy and interact with MyToken contract
/// @author Dilum Bandara, CSIRO's Data61

import { deploy, call, send, getAccounts } from './web3-lib-MyToken'
import Web3 from 'web3'

(async () => {
    const contractName = 'MyToken'  // Contract to deploy
    let contractAddress : string    // Address of the deployed contract
    const tokenName = 'Mint Token'
    const tokenSymbol = 'MNT'
    const totalSupply = 10000;
    
    const web3 = new Web3(web3Provider)
    const accounts = await getAccounts(web3)
    
    // Deploy contract as address 0
    try {
        const result = await deploy(web3, contractName, [tokenName, tokenSymbol, totalSupply], accounts[0])
        contractAddress = result.address
        console.log(`MyToken contract deployed at address: ${contractAddress}`)
    } catch (e) {
        console.log(e.message)
    }

    // Verify token symbol as address 0
    try {
        const receipt = await call(web3, contractName, contractAddress, 'symbol', [], accounts[0])
        console.log(`Token symbol is: ${receipt}`)
    } catch (e) {
        console.log(e.message)
    }

    // Verify token supply as address 2
    try {
        const receipt = await call(web3, contractName, contractAddress, 'totalSupply', [], accounts[2])
        console.log(`Total supply is: ${receipt}`)
    } catch (e) {
        console.log(e.message)
    }

    // Check token balance as token deployer
    try {
        const receipt = await call(web3, contractName, contractAddress, 'balanceOf', [accounts[0]], accounts[0])
        console.log(`Balance of token deployer is: ${receipt}`)
    } catch (e) {
        console.log(e.message)
    }

    // Transfer tokens from address 0 to address 1 and check balances
    try {
        const receipt1 = await send(web3, contractName, contractAddress, 'transfer', [accounts[1],2000], accounts[0])
        console.log(`20.00 tokens transferred from address ${accounts[0]} to address ${accounts[1]}`)

        // Check balance as address 0 and 1
        const receipt2 = await call(web3, contractName, contractAddress, 'balanceOf', [accounts[0]], accounts[0])
        console.log(`Balance of address 0 is: ${receipt2}`)
        const receipt3 = await call(web3, contractName, contractAddress, 'balanceOf', [accounts[1]], accounts[1])
        console.log(`Balance of address 1 is: ${receipt3}`)
    } catch (e) {
        console.log(e.message)
    }

})()

